import Button from './button';
import ToggleButton from './togglebutton';
import React, {useState} from 'react';
import SearchBar from './searchbar';
import ButtonBar, {ButtonsLeft, ButtonsMiddle, ButtonsRight, ButtonsCollapsing} from './buttonbar';
import {CompanyIcon, ProfileIcon, SettingsIcon} from  './icons';
import MainSearch from './mainsearch';

const mainSearch = new MainSearch(4);
// currentPage
const TopBar = ({ isGlassy, currentPage, pages, setCurrentPage }) => {
    const [searchResults, setSearchResults] = useState([]);
    return (
        <ButtonBar isGlassy={isGlassy} isSticky={true}>
            <ButtonsLeft>
                <Button 
                    displayName="Home" 
                    isCircle={true} 
                    extraClasses="hover:bg-hover/70 mx-2"
                    buttonAction={() => {
                        setCurrentPage(pages.home)
                    }}
                >
                    <CompanyIcon />
                </Button>
            </ButtonsLeft>
            <ButtonsMiddle>
                <SearchBar 
                    searchFunction={(searchTerm) => {
                        setSearchResults(mainSearch.search(searchTerm));
                    }}> 
                    {
                        searchResults.map((result) => {
                            return (
                                <span className='mr-2'>
                                    {result}
                                </span>
                            );
                        })
                    }
                </SearchBar>
            </ButtonsMiddle>
            <ButtonsRight>
                <ButtonsCollapsing currentPage={currentPage} displayName="Options" buttons={
                    {
                        collapsed: [
                            <ToggleButton 
                                extraClasses="px-3 hover:bg-hover/70"
                                displayName="Settings" 
                                isOn={currentPage.id === 'settings'} 
                                buttonAction={(isOn) => {
                                    if (isOn) {
                                        setCurrentPage(pages.settings);
                                    }
                                }}
                            >
                                <span className="flex">
                                    <SettingsIcon />
                                    <span className="px-2 text-left"> 
                                        Settings
                                    </span>
                                </span>
                            </ToggleButton>,
                            <ToggleButton 
                                extraClasses="px-3 hover:bg-hover/70"
                                displayName="Profile" 
                                isOn={currentPage.id === 'profile'} 
                                buttonAction={(isOn) => {
                                    if (isOn) {
                                        setCurrentPage(pages.profile);
                                    }
                                }}
                            >
                                <span className="flex">
                                    <ProfileIcon />
                                    <span className="px-2 text-left"> 
                                        Profile
                                    </span>
                                </span>
                            </ToggleButton>
                        ],
                        expanded: [
                            <ToggleButton 
                                displayName="Settings" 
                                isCircle={true} 
                                isOn={currentPage.id === 'settings'} 
                                extraClasses="hover:bg-hover/70  mx-2"
                                buttonAction={(isOn) => {
                                    setCurrentPage(pages.settings);
                                }
                            }>
                                <SettingsIcon />
                            </ToggleButton>,
                            <ToggleButton 
                                displayName="Profile" 
                                isCircle={true} 
                                isOn={currentPage.id === 'profile'} 
                                extraClasses="hover:bg-hover/70  mx-2" // test108 having the ml here is kinda dumb
                                buttonAction={(isOn) => {
                                    setCurrentPage(pages.profile);
                                }}
                            >
                                <ProfileIcon isInverted={currentPage.id === 'profile'} />
                            </ToggleButton>
                        ]
                    }
                }>
                </ButtonsCollapsing>
            </ButtonsRight>
        </ButtonBar>
    );
};

export default TopBar;