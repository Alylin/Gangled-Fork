import React, {useState, useEffect} from 'react';
import HomePage from './pages/homepage';
import SettingsPage from './pages/settingspage'
import ProfilePage from './pages/profilepage';
import TopBar from './topbar';
import { getTheme } from './utilities/theme';

function Primary() {
    const pages = {
        home: {
            page: <HomePage />,
            id: 'home'
        },
        profile: {
            page: <ProfilePage />,
            id: 'profile'
        },
        settings: {
            page: <SettingsPage />,
            id: 'settings'
        }
    }
    const [currentPage, setCurrentPage] = useState(pages.home);
    
    useEffect(() => { // test108 make arrows work on dropdown
        const onThemeChange = () => {
            const theme = getTheme();
            document.documentElement.setAttribute('data-theme', theme.getThemeClass())
        }
        onThemeChange();

        const themeCheck = window.matchMedia("(prefers-color-scheme: dark)");
        themeCheck.addEventListener('change', onThemeChange);
        
        return () => themeCheck.removeEventListener('change', onThemeChange);
    }, []);

    return (
        <div className="h-screen bg-primary">
            <div className="flex flex-col font-content bg-primary text-primary"> 
                <TopBar isGlassy={currentPage.id !== 'profile'} currentPage={currentPage} pages={pages} setCurrentPage={setCurrentPage} />
                {currentPage.page}
            </div>
        </div>
    );
}

export default Primary;