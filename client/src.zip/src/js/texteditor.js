
import classNames from 'classnames';
import { useEffect, useState } from 'react/cjs/react.development';
import sanitizeHtml from './utilities/sanitizer';

const undoStack = [];
const redoStack = [];

const maxStackSize = 100;

function addToRedoStack(html, range) {
    addToStack(html, range, redoStack);
}

function addToUndoStack(html, range) { 
    addToStack(html, range, undoStack);
}

function addToStack(html, range, stack) {
    stack.push({
        html: html,
        selectionRange: range
    });
    if (stack.length > maxStackSize) {
        stack.shift();
    }
    console.log(stack.length);
}

function undo(html, range) {
    if (undoStack.length) { 
        addToRedoStack(html, range);
        return undoStack.pop();
    }
}

function redo(html, range) {
    if (redoStack.length) { 
        addToUndoStack(html, range);
        return redoStack.pop();
    }
}

function TextEditor(props) {
    const {
        onChange,
        onFocus,
        onBlur,
        textInputRef
    } = props;

    const [pendingState, setPendingState] = useState({html: '', selectionRange: {start: 0, end: 0}});

    const onTextChange = (event) => {//test108 remove event         
        const selection = window.getSelection();
        const start = selection.anchorOffset
    
        addToUndoStack(pendingState.html, pendingState.selectionRange);

        const sanitizedHtml = sanitizeHtml(event.target.innerHTML);
        event.target.innerHTML = sanitizedHtml;
    
        const range = document.createRange();
        range.setStart(event.target.childNodes[0] || event.target, start);
        range.collapse(true);

        selection.removeAllRanges();
        selection.addRange(range);
        onChange(sanitizedHtml);
    }

    /*
        Break Conditions Creating:
            New word
            1 second pause
            Paste
        Break Conditions Deleting:
            New line
            1 second pause
            Cut/delete selection
        Break Conditions Other:
            Formatting
            Insert image/video
    */

    useEffect(() => {
        const onUndo = function (event) {
            var key = event.key;

            const selection = window.getSelection();
            const start = selection.anchorOffset;
            const end = selection.focusOffset;
        
            const sanitizedHtml = sanitizeHtml(event.target.innerHTML);

            if (event.ctrlKey) { // test108 make this work with cmd z later. 
                if (key === 'z') {
                    if (undoStack.length) {
                        event.preventDefault();

                        const newState = undo(sanitizedHtml, {
                            start: start,
                            end: end
                        });
                        event.target.innerHTML = newState.html;

                        const range = document.createRange();
                        range.setStart(event.target.childNodes[0] || event.target, newState.selectionRange.start);
                        range.setEnd(event.target.childNodes[0] || event.target, newState.selectionRange.end);

                        selection.removeAllRanges();
                        selection.addRange(range);
                    }
                }
                else if (key === 'y') {
                    if (redoStack.length) {
                        event.preventDefault();

                        const newState = redo(sanitizedHtml, {
                            start: start,
                            end: end
                        });
                        event.target.innerHTML = newState.html;

                        const range = document.createRange();
                        range.setStart(event.target.childNodes[0] || event.target, newState.selectionRange.start);
                        range.setEnd(event.target.childNodes[0] || event.target, newState.selectionRange.end);

                        selection.removeAllRanges();
                        selection.addRange(range);
                    }
                }
            }
        };

        document.addEventListener('keydown', onUndo);

        return () => {
            document.removeEventListener('keydown', onUndo);
        }
    });

    return (
        <div
            className={classNames('appearance-none outline-none bg-transparent w-full overflow-hidden whitespace-nowrap select-text')}
            contentEditable={true}
            onFocus={onFocus}
            onInput={onTextChange}
            onPaste={onTextChange}
            onKeyDown={(event) => {
                const selection = window.getSelection();
                const start = selection.anchorOffset;
                const end = selection.focusOffset;
        
                const sanitizedHtml = sanitizeHtml(event.target.innerHTML);
                setPendingState({html: sanitizedHtml, selectionRange: {start: start, end: end}});
            }}
            ref={textInputRef}
            onBlur={onBlur}
        />
    );
}

export default TextEditor;