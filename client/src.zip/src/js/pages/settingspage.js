import { useEffect, useRef } from 'react/cjs/react.development';
import ColorPicker from '../colorpicker';
import classNames from 'classnames';
import LittleDude from './battlemap/littledude';

function getMousePos(canvas, evt) {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
  
    return {
        x: (evt.clientX - rect.left) * scaleX,
        y: (evt.clientY - rect.top) * scaleY
    }
}

{/* <Button displayName={displayName} isCircle={true} buttonAction={() => {
    setIsDropdownVisible(true);
}} onFocus={() => {
    setIsDropdownVisible(true);
}}>
    <MenuIcon />
</Button> */}

function SettingsPage() {
    let littleDude;
    const canvasRef = useRef();
    useEffect(() => {
        littleDude = new LittleDude(5, 5, 50, 20, []);
        const intervalId = window.setInterval(() => { //requestAnimationFrame
            const ctx = canvasRef.current.getContext("2d");
            ctx.save();
            ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);

            littleDude.tick();
            littleDude.paint(canvasRef.current);
            ctx.restore();
        }, 30);

        return () => {
            clearInterval(intervalId);
        }
    });
    return (
        <div className="p-6 font-semibold">
            <div onClick={() => {
                littleDude = new LittleDude(5, 5, 50, 20, []);
            }}> 
                test
            </div>
            <ColorPicker />
            {navigator.languages}
            {/* {navigator.geolocation.getCurrentPosition((geolocationPosition) => {
                alert(geolocationPosition.coords.latitude+', '+geolocationPosition.coords.longitude);
            })} */}
            <div>
                <canvas 
                    ref={canvasRef}
                    id="canvas" 
                    width="384" 
                    height="384" 
                    className={classNames('w-96 h-96 cursor-grab bg-white')}
                    onMouseMove={(event) => {
                        if (littleDude.grabbedPos) {
                            const canvas = event.target;
                            const pos = getMousePos(canvas, event);
                            littleDude.onMove(pos);
                        }
                    }}
                    onMouseDown={(event) => {
                        const canvas = event.target;
                        const pos = getMousePos(canvas, event);
                        if (littleDude.hitTest(pos.x, pos.y)) {
                            littleDude.onGrab(pos);
                        }
                    }}
                    onMouseUp={() => {
                        littleDude.onRelease();
                    }}
                />
            </div>
        </div>
    );
}

export default SettingsPage;