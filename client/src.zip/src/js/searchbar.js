import React, {Fragment, useEffect, useState} from 'react';
import classNames from 'classnames';
import {CloseIcon, SearchIcon} from './icons';
import Dropdown from './dropdown';
import debounceCancellable from './debouncecancellable';
import TextEditor from './texteditor';
import isDarkTheme from './utilities/theme';

function Placeholder() {
    return (
        <Fragment>
            <SearchIcon />
            <span className="inline-block align-middle overflow-hidden overflow-ellipsis max-w-full whitespace-nowrap pl-2">
                Search
            </span>
        </Fragment>
    );
}

function SearchBar(props) {
    const {
        extraClasses, children, searchFunction
    } = props;

    const [isFocused, setIsFocused] = useState(false);
    const [hasSearchText, setHasSearchText] = useState(false);
    const [canShowResults, setCanShowResults] = useState(false);

    const debouncedFunctions = debounceCancellable(searchFunction);
    const searchFunctionDebounced = debouncedFunctions.functionDebounced;
    const searchFunctionImmediate = debouncedFunctions.functionImmediate;
    let textInput = React.createRef();
    let wrapperRef = React.createRef();

    useEffect(() => {
        if (textInput.current && isFocused) {
            textInput.current.focus();
        }
    }, [isFocused]);

    return ( //test108 length can get too much
        <div className="relative w-full max-w-5xl" ref={wrapperRef}>
            <div className={classNames('px-3 py-2 flex cursor-text select-none rounded-full whitespace-nowrap h-10 shadow-lg bg-opacity-75 hover:bg-hover/70 bg-secondary/70', extraClasses)} 
                title="Search" 
                tabIndex={0} 
                onFocus={() => {
                    setCanShowResults(true);
                    setIsFocused(true);
                }}>
                {
                    (isFocused || hasSearchText) &&
                    <Fragment>
                        <span 
                            title="" 
                            className={classNames('bg-secondary hover:bg-hover', isDarkTheme() ? 'bg-secondary hover:bg-hover bgshadow-dark-3d hover:shadow-dark-3dInverese' : 'shadow-3d hover:shadow-3dInverese', 'cursor-pointer px-2 rounded-full font-medium mr-1 text-center text-sm')}
                        >
                            #diagram
                        </span>
                        <TextEditor 
                            onChange={(searchTerm) => {
                                setHasSearchText(!!searchTerm.length);
                                searchFunctionDebounced(searchTerm);
                            }}
                            onFocus={() => {
                                setIsFocused(true);
                            }}
                            onBlur={() => {
                                setIsFocused(false);
                            }}
                            textInputRef={textInput}
                            />


                    </Fragment>
                }
                {hasSearchText && 
                    <span onClick={() => {
                        textInput.current.value = '';
                        setHasSearchText(false);
                        setIsFocused(false);
                        setCanShowResults(false);
                        searchFunctionImmediate('');
                        textInput.current.focus(); 
                    }}>
                        <CloseIcon />
                    </span>
                }
                {!isFocused && !hasSearchText && <Placeholder />}
            </div>
            <Dropdown extraClasses="w-full flex flex-col lg:flex-row pt-3" clickZone={wrapperRef} canDisplay={canShowResults} setCanDisplay={(canDisplay) => {
                setCanShowResults(canDisplay);
            }}>
                {children}
            </Dropdown>
        </div>
    );
}

export default SearchBar;