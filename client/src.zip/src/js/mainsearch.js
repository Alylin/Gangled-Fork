import Panel from './panel';

const searchableThings = [
    {
        displayName: 'Cerberus',
        description: 'a three headed dog, pet of Hades.',
        imagePath: '../examplebackground1.jpg'
    }, 
    {
        displayName: 'Cyclopes',
        description: 'one-eyed giants.',
        imagePath: '../examplebackground2.jpg'
    }, 
    {
        displayName: 'Gigantes',
        description: 'were a race of great strength and aggression. Archaic and Classical representations show Gigantes as human in form. Later representations show Gigantes with snakes for legs.',
        imagePath: '../examplebackground3.jpg'
    }, 
    {
        displayName: 'Gorgons',
        description: 'female monsters depicted as having snakes on their head instead of hair, and sometimes described as having tusks, wings and brazen claws.',
        imagePath: '../examplebackground4.jpg'
    }, 
    {
        displayName: 'Manticore',
        description: 'having the body of a red lion and a human head with three rows of sharp teeth. The manticore can shoot spikes out of its tail, making it a deadly foe.',
        imagePath: '../examplebackground5.jpg'
    }, 
    {
        displayName: 'Merpeople',
        description: 'humans with fish tail after torso (Mermaid as female, Merman as male). They lure adventurers to drown them.',
        imagePath: '../examplebackground6.jpg'
    }, 
    {
        displayName: 'Ouroboros',
        description: 'an immortal self-eating, circular being. The being is a serpent or a dragon curled into a circle or hoop, biting its own tail.',
        imagePath: '../examplebackground7.jpg'
    }, 
    {
        displayName: 'Philinnion',
        description: 'unwed maiden who died prematurely and returned from the tomb as the living dead to consort with a handsome youth named Makhates. When her mother discovered the girl she collapsed back into death and was burned by the terrified townsfolk beyond the town boundaries.',
        imagePath: '../examplebackground8.jpg'
    }, 
    {
        displayName: 'Phoenix',
        description: 'a golden-red fire bird of which only one could live at a time, but would burst into flames to rebirth from ashes as a new phoenix.',
        imagePath: '../examplebackground9.jpg'
    }, 
    {
        displayName: 'Sirens',
        description: 'bird-like women whose irresistible song lured sailors to their deaths.',
        imagePath: '../examplebackground10.jpg'
    }, 
    {
        displayName: 'Sphinx',
        description: 'Androsphinx or simply Sphinx, a creature with the head of a human and the body of a lion.',
        imagePath: '../examplebackground11.jpg'
    }, 
    {
        displayName: 'Pegasus',
        description: 'a divine winged stallion that is pure white, son of Medusa and Poseidon, brother of Chrysaor and father of winged horses.',
        imagePath: '../examplebackground12.jpg'
    }, 
    {
        displayName: 'Amphisbaena',
        description: 'a serpent with a head at each end.',
        imagePath: '../examplebackground13.jpg'
    }, 
    {
        displayName: 'Chimera',
        description: 'a fire-breathing, three-headed monster with one head of a lion, one of a snake, and another of a goat, lion claws in front and goat legs behind, and a long snake tail.',
        imagePath: '../examplebackground14.jpg'
    }, 
    {
        displayName: 'Mario',
        description: 'Super Mario Brothers',
        imagePath: '../examplebackground15.jpg'
    }, 
    {
        displayName: 'Link',
        description: 'The Legend of Zelda',
        imagePath: '../examplebackground16.jpg'
    },
    {
        displayName: 'Kirby',
        description: 'Kirby\'s Dreamland',
        imagePath: '../examplebackground19.jpg'
    }, 
    {
        displayName: 'Samus',
        description: 'Metroid',
        imagePath: '../examplebackground20.jpg'
    },
    {
        displayName: 'King Dedede',
        description: 'Kirby\'s Dreamland',
        imagePath: '../examplebackground22.jpg'
    }, 
    {
        displayName: 'Villager',
        description: 'Animal Crossing',
        imagePath: '../examplebackground23.jpg'
    }, 
    {
        displayName: 'Pichu',
        description: 'Pokemon',
        imagePath: '../examplebackground24.jpg'
    }, 
    {
        displayName: 'Yoshi',
        description: 'Super Mario World',
        imagePath: '../examplebackground26.jpg'
    }, 
    {
        displayName: 'Zelda',
        description: 'The Legend of Zelda',
        imagePath: '../examplebackground27.jpg'
    }, 
    {
        displayName: 'Fox',
        description: 'Star Fox',
        imagePath: '../examplebackground28.jpg'
    }, 
    {
        displayName: 'Mewtwo',
        description: 'Pokemon',
        imagePath: '../examplebackground29.jpg'
    }, 
    {
        displayName: 'Olimar',
        description: 'Pikmin',
        imagePath: '../examplebackground30.jpg'
    }, 
    {
        displayName: 'R.O.B.',
        description: 'Peripheral for the NES',
        imagePath: '../examplebackground31.jpg'
    }, 
    {
        displayName: 'Ryu',
        description: 'Street Figher',
        imagePath: '../examplebackground32.jpg'
    }, 
    {
        displayName: 'Pit',
        description: 'Kid Icarus',
        imagePath: '../examplebackground33.jpg'
    }
];

function scoreResult(result, searchTerm) { // test108 break apart the result for things too. Arabic worries, define more breakers. 
    const displayName = result.displayName.toLowerCase().trim()
    if (displayName === searchTerm) {
        return 100;
    }
    if (displayName.startsWith(searchTerm)) {
        return 50;
    }
    const nameParts = displayName.split(' ')
    for (let i = 0; i < nameParts.length; i++) {
        let namePart = nameParts[i];
        if (namePart === searchTerm) {
            return 30;
        }
        if (namePart.startsWith(searchTerm)) {
            return 20;
        }
    }
    return 0;
}

function NoResults(props) {
    return (
        <span className="italic max-w-full truncate">
            {`We couldn't find any results for "${props.searchTerm}"`}
        </span>
    );
} 

class MainSearch{
    constructor(resultsLimit) {
        this.resultsLimit = resultsLimit;
    }

    search(searchTerm) {
        searchTerm = searchTerm.toLowerCase().trim();
        const searchResults = searchableThings.filter((searchableThing) => {
            return searchableThing.displayName.toLowerCase().trim().includes(searchTerm);
        }).sort((a, b) => {
            return scoreResult(b, searchTerm) - scoreResult(a, searchTerm);
        }).slice(0, this.resultsLimit);

        if (searchResults.length) {
            return searchResults.map((result) => {
                return <Panel isLoading={false} displayName={result.displayName} description={result.description} imagePath={result.imagePath} />;
            });
        }
        return [
            <NoResults searchTerm={searchTerm}/>
        ];
    }
}

export default MainSearch;