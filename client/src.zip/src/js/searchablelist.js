import React, {useState, useRef, useEffect} from 'react';
import {SearchIcon} from './icons';
import classNames from 'classnames';
import MainSearch from './mainsearch';
import Draggable from 'react-draggable';

function ScrollThumb({ position, onDrag, onStart, onStop, size, isVertical}) {
    const thumbRef = useRef();
    return (
        <Draggable 
            axis={isVertical ? 'y' : 'x'}
            bounds="parent" 
            position={{x: isVertical ? 0 : position, y: !isVertical ? 0 : position}}
            onDrag={() => {
                onDrag(thumbRef.current);
            }}
            onStart={() => {
                onStart();
            }}
            onStop={() => {
                onStop();
            }}
        >
            <div 
                className={classNames('bg-tertiary rounded-full absolute', isVertical ? 'w-3' : 'h-3')}
                style={isVertical ? {height:`${size}px`} : {width:`${size}px`}}
                data-isThumb
                ref={thumbRef}
            />
        </Draggable>
    )
}

function ScrollBar({positionPercent, onDrag, desiredSize, isVertical, onStart, onStop}) {
    const scrollRef = useRef();
    const [size, setSize] = useState(0);
    useEffect(() => {
        setSize(Math.max(desiredSize, 80));
    });
    return (
        <span 
            className={classNames(isVertical ? 'h-full w-3' : 'w-full h-3', 'absolute z-30 right-0')}
            ref={scrollRef}
        >
            <ScrollThumb isVertical={isVertical} position={((isVertical ? scrollRef?.current?.clientHeight : scrollRef?.current?.clientWidth) * positionPercent)-(positionPercent*size) || 0} onDrag={onDrag} onStart={onStart} onStop={onStop} size={size} />
        </span>
    )
}

function ScrollArea({ children }) {
    const [positionPercent, setPositionPercent] = useState({x: 0, y: 0});
    const scrollingArea = useRef();
    const [desiredScrollThumbWidth, setDesiredScrollThumbWidth] = useState(false);
    const [desiredScrollThumbHeight, setDesiredScrollThumbHeight] = useState(false);

    const [isDragging, setIsDragging] = useState(false);

    useEffect(() => {
        function onScroll() {
            if (!isDragging) {
                setPositionPercent({
                    x: (scrollingArea.current.scrollLeft) / (scrollingArea.current.scrollWidth - scrollingArea.current.getBoundingClientRect().width), 
                    y: (scrollingArea.current.scrollTop) / (scrollingArea.current.scrollHeight - scrollingArea.current.getBoundingClientRect().height) // thumb.getBoundingClientRect().top - thumb.parentNode.getBoundingClientRect().top) / (thumb.parentNode.getBoundingClientRect().height - thumb.getBoundingClientRect().height
                });
            }
        }
        scrollingArea.current.addEventListener('scroll', onScroll);
        return () => {
            scrollingArea.current?.removeEventListener('scroll', onScroll);
        }
    });

    useEffect(() => {
        const originalOnSelectStart = document.onselectstart;
        document.onselectstart = (event) => {
            return !event.target.hasAttribute('data-isThumb'); // cancel selection
        };
        return () => {
            document.onselectstart = originalOnSelectStart;
        };
    });
    // test108 Clicking active tab closes it. 
    useEffect(() => {
        const onResize = () => {
            if (scrollingArea.current) {
                scrollingArea.current.scrollTo(
                    (positionPercent.x * scrollingArea.current.scrollWidth) - (scrollingArea.current.getBoundingClientRect().width * positionPercent.x), 
                    (positionPercent.y * scrollingArea.current.scrollHeight) - (scrollingArea.current.getBoundingClientRect().height * positionPercent.y)
                );
                if ((scrollingArea.current.scrollWidth - scrollingArea.current.getBoundingClientRect().width) > 10) {
                    setDesiredScrollThumbWidth((scrollingArea.current.getBoundingClientRect().width / scrollingArea.current.scrollWidth) * scrollingArea.current.getBoundingClientRect().width);
                }
                else {
                    setDesiredScrollThumbWidth(0);
                }
                if ((scrollingArea.current.scrollHeight - scrollingArea.current.getBoundingClientRect().height) > 10) {
                    setDesiredScrollThumbHeight((scrollingArea.current.getBoundingClientRect().height / scrollingArea.current.scrollHeight) * scrollingArea.current.getBoundingClientRect().height);
                }
                else {
                    setDesiredScrollThumbHeight(0);
                }
            }
        };
        onResize();
        const resizeObserver = new ResizeObserver(onResize);
    
        resizeObserver.observe(scrollingArea.current);

        return () => {
            resizeObserver.disconnect();
        }
    }, [positionPercent, children]);

    return (
        <div className={classNames(desiredScrollThumbWidth && 'pb-4', desiredScrollThumbHeight && 'pr-4', 'relative overflow-hidden')}>
            {!!desiredScrollThumbWidth && positionPercent.x !== 0 &&
                <span className={'absolute h-full lg:w-5 z-20 left-0 top-0'}>
                    <div className="from-primary bg-gradient-to-r h-full w-full" />
                </span> 
            }
            <div className="flex">
                <div 
                    ref={scrollingArea}
                    className="flex flex-1 flex-col lg:flex-row overflow-auto max-h-80 hideScrollBar" // 
                >
                    {children}
                </div>
                {!!desiredScrollThumbHeight && 
                    <ScrollBar 
                        positionPercent={positionPercent.y} 
                        onDrag={(thumb) => {
                            setPositionPercent({
                                x: positionPercent.x,
                                y: Math.round(thumb.getBoundingClientRect().top - thumb.parentNode.getBoundingClientRect().top) / Math.round(thumb.parentNode.getBoundingClientRect().height - thumb.getBoundingClientRect().height)
                            });
                        }} 
                        onStart={() => {
                            setIsDragging(true);
                        }} 
                        onStop={() => {
                            setIsDragging(false);
                        }}
                        desiredSize={desiredScrollThumbHeight}
                        isVertical={true}
                    />
                }
            </div>
            {!!desiredScrollThumbWidth && // test108 scrollingArea.current.scrollWidth > scrollingArea.current.getBoundingClientRect().width
                <ScrollBar 
                    positionPercent={positionPercent.x} 
                    onDrag={(thumb) => {
                        setPositionPercent({
                            x: Math.round(thumb.getBoundingClientRect().left - thumb.parentNode.getBoundingClientRect().left) / Math.round(thumb.parentNode.getBoundingClientRect().width - thumb.getBoundingClientRect().width),
                            y: positionPercent.y
                        });
                    }} 
                    onStart={() => {
                        setIsDragging(true);
                    }}
                    onStop={() => {
                        setIsDragging(false);
                    }}
                    desiredSize={desiredScrollThumbWidth}
                />
            }
            {!!desiredScrollThumbWidth && positionPercent.x < 0.999 &&
                <span className={'absolute h-full lg:w-5 z-20 right-0 top-0'}>
                    <div className="from-primary bg-gradient-to-l h-full w-full" />
                </span>
            }
        </div>
    )
}

function SearchableList(props) {
    const mainSearch = new MainSearch(100);

    const {
        displayName,
    } = props;

    const [isShowingSearch, setIsShowingSearch] = useState(false);
    const [isInitialState, setIsInitialState] = useState(true);
    const textInputRef = useRef();
    const [searchResults, setSearchResults] = useState(mainSearch.search(''));

    return (
        <div className="relative">
            <div 
            className="text-lg relative font-semibold cursor-text pb-2 flex" 
            onClick={() => {
                textInputRef.current.focus();
            }}
            >
                <span className="inline-block absolute font-title mx-1">
                    {displayName}
                </span>
                <span className="flex-1" />
                <span className="inline-block z-10 pt-1 bg-primary">
                    <SearchIcon />
                </span>
                <input 
                    onFocus={() => {
                        setIsShowingSearch(true);
                        setIsInitialState(false);
                    }}
                    onBlur={() => {
                        setIsShowingSearch(!!textInputRef.current.value);
                    }}
                    ref={textInputRef}
                    type="text" 
                    className={classNames('outline-none z-10 overflow-hidden bg-primary', isInitialState && 'w-0', !isInitialState && (isShowingSearch ? 'w-full animate-expandHorizontalFull' : 'w-0 animate-collapseHorizontalFull'))}
                    onChange={(event) => {
                        const searchTerm = event.target.value.trim();
                        setSearchResults(mainSearch.search(searchTerm))
                    }}
                />
            </div>
            <ScrollArea>
                {searchResults.map((result) => (
                    <div className="snap-start lg:mr-2 lg:last:mr-0 lg:mb-0 lg:last:mb-0 mb-2 last:mb-0">
                        {result}
                    </div>
                ))}
            </ScrollArea>
        </div>
    );
}

export default SearchableList;